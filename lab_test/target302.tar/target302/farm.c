/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_248(unsigned x)
{
    return x + 3281031256U;
}

void setval_298(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_191()
{
    return 3284633928U;
}

void setval_252(unsigned *p)
{
    *p = 2425393176U;
}

void setval_266(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_386()
{
    return 1214889806U;
}

unsigned addval_131(unsigned x)
{
    return x + 3351742792U;
}

unsigned addval_443(unsigned x)
{
    return x + 3349760180U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_281()
{
    return 2464188744U;
}

unsigned addval_136(unsigned x)
{
    return x + 3221799305U;
}

unsigned getval_419()
{
    return 3523791499U;
}

void setval_160(unsigned *p)
{
    *p = 3375942281U;
}

unsigned getval_125()
{
    return 3767355605U;
}

unsigned getval_257()
{
    return 2425473673U;
}

unsigned addval_277(unsigned x)
{
    return x + 2430634440U;
}

unsigned addval_370(unsigned x)
{
    return x + 3767093252U;
}

unsigned getval_181()
{
    return 2425405825U;
}

void setval_227(unsigned *p)
{
    *p = 3221277321U;
}

void setval_395(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_372()
{
    return 3531921037U;
}

unsigned getval_107()
{
    return 3523264905U;
}

unsigned addval_324(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_288(unsigned x)
{
    return x + 2425405825U;
}

void setval_490(unsigned *p)
{
    *p = 3281043849U;
}

unsigned addval_100(unsigned x)
{
    return x + 3374372553U;
}

unsigned addval_105(unsigned x)
{
    return x + 3230979721U;
}

unsigned addval_186(unsigned x)
{
    return x + 3281049225U;
}

void setval_114(unsigned *p)
{
    *p = 3381974665U;
}

unsigned getval_403()
{
    return 3768142042U;
}

unsigned addval_225(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_176()
{
    return 3281046153U;
}

unsigned addval_200(unsigned x)
{
    return x + 3526940297U;
}

unsigned getval_145()
{
    return 3531915656U;
}

void setval_391(unsigned *p)
{
    *p = 3676883593U;
}

unsigned getval_222()
{
    return 3525367305U;
}

unsigned addval_384(unsigned x)
{
    return x + 3374896777U;
}

void setval_221(unsigned *p)
{
    *p = 3250686341U;
}

unsigned getval_438()
{
    return 3531917960U;
}

unsigned getval_124()
{
    return 3221275017U;
}

unsigned getval_496()
{
    return 3525888649U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
